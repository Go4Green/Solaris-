﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.DependencyInjection;
using Solaris.Data;
using Solaris.Hubs;

namespace Solaris.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SolarisController : ControllerBase
    {
        private readonly IHubContext<SolarisHub> dokimi;
        private readonly ApplicationDbContext context;

        public SolarisController(IHubContext<SolarisHub> connectionManage, ApplicationDbContext context)
        {
            dokimi = connectionManage;
            this.context = context;

        }

        // GET: api/Solaris
        [HttpGet]
        public IEnumerable<MessageD> Get()
        {
            var messages = context.Messages.OrderByDescending(x => x.TimeUtc).ToList();
            var result = Newtonsoft.Json.JsonConvert.SerializeObject(messages);
            return messages;
        }

        // GET: api/Solaris/5
        [HttpGet("{dev_id}", Name = "Get")]
        public IEnumerable<MessageD> Get(string dev_id)
        {
            var messages = context.Messages.Where(x => x.DevId == dev_id).OrderByDescending(x => x.TimeUtc).ToList();
            return messages;
        }

        // POST: api/Solaris
        [HttpPost]
        public void Post([FromBody] Message value)
        {
            var message = new MessageD();
            message.Id = Guid.NewGuid().ToString();
            message.DevId = value.dev_id;
            message.Battery = value.payload_fields.Battery;
            message.TimeUtc = DateTime.UtcNow;
            message.Temperature = (decimal)value.payload_fields.Temperature;
            message.HardwareSerial = value.hardware_serial == null ? string.Empty : value.hardware_serial;
            message.Counter = value.counter;
            message.Event = value.payload_fields.Event == null ? string.Empty : value.payload_fields.Event;
            message.Light = value.payload_fields.Light;
            message.Battery = value.payload_fields.Battery;
            message.ReceivedString = value.payload_fields.ReceivedString == null ? string.Empty : value.payload_fields.ReceivedString;
            context.Add<MessageD>(message);
            context.SaveChanges();
            this.dokimi.Clients.All.SendAsync("ReceiveMessage", message, value.payload_fields.Light.ToString(), value.payload_fields.Temperature.ToString()).Wait();
        }
    }
}
