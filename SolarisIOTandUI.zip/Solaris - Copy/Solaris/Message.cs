﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;

namespace Solaris
{
    public class MessageD
    {
        [Key]
        [JsonIgnore]
        public string Id { get; set; }

        public string DevId { get; set; }

        public string HardwareSerial { get; set; }

        public int Counter { get; set; }

        public DateTime TimeUtc { get; set; }

        public int Battery { get; set; }

        public string Event { get; set; }

        public int Light { get; set; }

        public decimal Temperature { get; set; }

        public string ReceivedString { get; set; }
    }

    public class Message
    {
        public string app_id { get; set; }

        public string dev_id { get; set; }

        public string hardware_serial { get; set; }

        public int port { get; set; }

        public int counter { get; set; }

        public string payload_raw { get; set; }

        public PayLoadFields payload_fields { get; set; }    
    }

    [JsonObject]
    public class PayLoadFields
    {
        [JsonProperty("battery")]
        public int Battery { get; set; }

        [JsonProperty("event")]
        public string Event { get; set; }

        [JsonProperty("light")]
        public int Light { get; set; }

        [JsonProperty("temperature")]
        public double Temperature { get; set; }

        [JsonProperty("receivedString")]
        public string ReceivedString { get; set; }
    }
}