﻿
"use strict";

var connection = new signalR.HubConnectionBuilder().withUrl("/solarisHub").build();

//Disable send button until connection is established
//document.getElementById("sendButton").disabled = true;

connection.on("ReceiveMessage", function (message) {
    var encodedMsg = JSON.stringify(message);
    var li = document.createElement("li");
    li.textContent = encodedMsg;
    document.getElementById("messagesList").appendChild(li);
    var powerGauge = $("#power-gauge").data("kendoRadialGauge");
    powerGauge.allValues([message.counter]);
    document.getElementById('power-gauge-value').innerHTML = message.counter + ' KW/h';

    var gauge = $("#gauge").data("kendoLinearGauge");
    gauge.allValues([parseFloat(message.temperature)]);

    var gauge = $("#gauge-b").data("kendoLinearGauge");
    gauge.allValues([parseFloat(message.light)]);

    $("#see").text = message.temperature + "C temperature";
});

connection.start().then(function () {
    document.getElementById("sendButton").disabled = false;
}).catch(function (err) {
    return console.error(err.toString());
});

document.getElementById("sendButton").addEventListener("click", function (event) {
    var user = document.getElementById("userInput").value;
    var message = document.getElementById("messageInput").value;
    connection.invoke("SendMessage", user, message).catch(function (err) {
        return console.error(err.toString());
    });
    event.preventDefault();
});
