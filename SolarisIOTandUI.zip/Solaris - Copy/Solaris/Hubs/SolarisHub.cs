﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace Solaris.Hubs
{
    public class SolarisHub : Hub//<ISolarisHub>
    {
        public async Task SendMessage(string user, string message)
        {
            await Clients.All.SendAsync("ReceiveMessage", null, user, message);
        }
    }
    
    //public interface ISolarisHub
    //{
    //    Task SendAsync(string see, string user, string message);
    //}
}
